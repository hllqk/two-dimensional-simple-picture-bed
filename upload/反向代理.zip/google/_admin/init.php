<?php
	error_reporting(E_ALL & ~ E_NOTICE );
	define('ADIR', str_replace("\\", "/", dirname(__FILE__)).'/');
	require ADIR.'includes/Snoopy.class.php';
	require ADIR.'includes/function.php';
	
