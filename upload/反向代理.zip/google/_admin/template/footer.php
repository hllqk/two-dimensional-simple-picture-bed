	<div class="bottom">
		<div id="copyright">	
		&copy;2011 7eam - <a href='http://code.google.com/p/7ghost/'>�ٷ���վ</a> - <a href='http://www.7eam.com'>�ٷ���̳</a> 
		</div>
	</div>
</div><!-- end .doc -->
</body>
</html>